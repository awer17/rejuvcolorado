function hrefto() {
        window.location.href = "https://rejuvaesthetics.myaestheticrecord.com/book/appointments"
}

function linkDescont(){
        window.location.href ="discounts.html"
}