function hrefto() {
        window.location.href = "https://rejuvaesthetics.myaestheticrecord.com/book/appointments"
}

function linkDescont(){
        window.location.href ="discounts.html"
}
function serviceslink(){
        window.location.href = "servises.html";
}